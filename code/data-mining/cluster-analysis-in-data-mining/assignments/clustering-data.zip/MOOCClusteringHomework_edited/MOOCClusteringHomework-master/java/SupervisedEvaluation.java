public class SupervisedEvaluation
{
    public static double purity(int[] groundtruthAssignment, int[] algorithmAssignment) {
        // TODO compute the purity
        return 0.0;
    }
    
    public static double NMI(int[] groundtruthAssignment, int[] algorithmAssignment) {
        // TODO compute the purity
        return 0.0;
    }
}
