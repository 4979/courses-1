public class KernelKMeans
{
    public static double[][] kernel(double[][] data, double sigma) {
        // TODO transform the data points to kernel space
        // here we are going to implement RBF kernel, K(x_i, x_j) = e^{\frac{-|x_i - x_j|^2}{2 \sigma^2}}
        return data;
    }
}
