from math import log, sqrt

def  purity(groundtruthAssignment, algorithmAssignment):

    purity = 0
    # TODO  
    # Compute the purity 
    return purity 


def NMI(groundtruthAssignment, algorithmAssignment):

    NMI = 0
    # TODO
    # Compute the NMI

    return NMI
